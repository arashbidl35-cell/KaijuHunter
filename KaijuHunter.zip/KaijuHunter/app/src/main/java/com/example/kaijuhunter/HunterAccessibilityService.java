package com.example.kaijuhunter;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import java.util.List;

public class HunterAccessibilityService extends AccessibilityService {
    private static final String PREF="hunter_prefs", KEY="enabled";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long lastClick=0;
    private int missingCount=0;
    private boolean scanQueued=false;
    public static void setEnabled(Context c, boolean v){ c.getSharedPreferences(PREF,0).edit().putBoolean(KEY,v).apply(); }
    public static boolean isEnabled(Context c){ return c.getSharedPreferences(PREF,0).getBoolean(KEY,false); }
    @Override public void onAccessibilityEvent(AccessibilityEvent event){ scheduleScan(); }
    @Override public void onInterrupt() { }
    @Override public void onServiceConnected(){ super.onServiceConnected(); scheduleScan(); }
    private void scheduleScan(){ if(scanQueued) return; scanQueued=true; handler.postDelayed(() -> { scanQueued=false; scan(); }, 800); }
    private void scan(){
        if(!isEnabled(this)) return;
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root==null) return;
        // Never interact with other apps. Telegram package names may differ for official/store variants.
        CharSequence pkg=root.getPackageName();
        if(pkg==null || !(pkg.toString().equals("org.telegram.messenger") || pkg.toString().equals("org.telegram.messenger.web") || pkg.toString().equals("uz.unnarsx.telegram")==true)) return;
        AccessibilityNodeInfo next=findText(root,"حریف بعدی");
        if(next!=null){
            missingCount=0;
            long now=System.currentTimeMillis();
            if(now-lastClick>=1800){
                AccessibilityNodeInfo clickable=next;
                while(clickable!=null && !clickable.isClickable()) clickable=clickable.getParent();
                if(clickable!=null){ clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK); lastClick=now; }
            }
        } else {
            // Safe default: stop as soon as the expected button is absent (event, other screen, or unexpected layout).
            missingCount++;
            if(missingCount>=2) setEnabled(this,false);
        }
    }
    private AccessibilityNodeInfo findText(AccessibilityNodeInfo node, String target){
        if(node==null) return null;
        CharSequence t=node.getText(); CharSequence d=node.getContentDescription();
        if((t!=null && t.toString().trim().equals(target)) || (d!=null && d.toString().trim().equals(target))) return node;
        for(int i=0;i<node.getChildCount();i++){
            AccessibilityNodeInfo found=findText(node.getChild(i),target);
            if(found!=null) return found;
        }
        return null;
    }
}
