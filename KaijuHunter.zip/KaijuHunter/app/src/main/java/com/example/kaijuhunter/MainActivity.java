package com.example.kaijuhunter;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView status;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout layout = new LinearLayout(this); layout.setOrientation(LinearLayout.VERTICAL); layout.setPadding(32,48,32,32);
        TextView title = new TextView(this); title.setText("Kaiju Hunter"); title.setTextSize(26); layout.addView(title);
        TextView info = new TextView(this); info.setText("خودکار فقط روی دکمهٔ «حریف بعدی» کلیک می‌کند. اگر دکمه ناپدید شود، اتوماسیون متوقف می‌شود تا ایونت را دستی انجام بدهی. دکمهٔ حمله هرگز کلیک نمی‌شود."); info.setTextSize(16); info.setPadding(0,24,0,24); layout.addView(info);
        Button accessibility = new Button(this); accessibility.setText("۱) باز کردن تنظیمات دسترس‌پذیری"); accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); layout.addView(accessibility);
        Button enable = new Button(this); enable.setText("۲) شروع / ادامهٔ شکار خودکار"); enable.setOnClickListener(v -> { HunterAccessibilityService.setEnabled(this, true); Toast.makeText(this,"شکار خودکار فعال شد؛ به تلگرام و شکارگاه برگرد.",Toast.LENGTH_LONG).show(); refresh(); }); layout.addView(enable);
        Button stop = new Button(this); stop.setText("توقف اضطراری"); stop.setOnClickListener(v -> { HunterAccessibilityService.setEnabled(this,false); Toast.makeText(this,"اتوماسیون متوقف شد",Toast.LENGTH_SHORT).show(); refresh(); }); layout.addView(stop);
        status = new TextView(this); status.setTextSize(15); status.setPadding(0,24,0,0); layout.addView(status);
        setContentView(layout); refresh();
    }
    private void refresh(){ if(status!=null) status.setText("وضعیت: "+(HunterAccessibilityService.isEnabled(this)?"فعال (در نبود دکمهٔ حریف بعدی خودکار متوقف می‌شود)":"متوقف")); }
}
